<!DOCTYPE html>
<html lang="en" class="wide wow-animation smoothscroll scrollTo">
  <head>
    <!-- Site Title-->
    <?PHP
      $username = $_POST['login'];
      $username = md5($_GET['login']);
    ?>
      <title>Welcome!</title>
      <body>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="keywords" content="intense web design multipurpose template">
    <meta name="date" content="Dec 26">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=PT+Sans:400,400italic,700,700italic%7CMontserrat:400,700">
    <link rel="stylesheet" href="css/style.css">
		<!--[if lt IE 10]>
    <div style="background: #212121; padding: 10px 0; box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3); clear: both; text-align:center; position: relative; z-index:1;"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <script src="js/html5shiv.min.js"></script>
		<![endif]-->
  </head>
    <!-- Page-->
    <div class="page text-center">
      <!-- Page Head-->
      <header class="page-head">
        <!-- RD Navbar Top Panel-->
        <div class="rd-navbar-wrap">
          <nav data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-static" data-md-stick-up-offset="100px" data-lg-stick-up-offset="110px" data-auto-height="false" class="rd-navbar rd-navbar-top-panel rd-navbar-default rd-navbar-white" data-lg-auto-height="true" data-md-layout="rd-navbar-fullwidth" data-lg-layout="rd-navbar-static" data-lg-stick-up="true">
            <div class="rd-navbar-inner">
              <!-- RD Navbar Top Panel-->
              <div class="rd-navbar-top-panel bg-ebony-clay">
                <div class="left-side">
                  <!-- Contact Info-->
                  <address class="contact-info text-left">
                    <div class="reveal-inline-block"><a href="callto:#" class="unit unit-middle unit-horizontal unit-spacing-xs"><span class="unit-left"><span class="icon icon-xxs icon-warning icon-circle mdi mdi-phone"></span></span><span class="unit-body"><span class="text-alto">1-800-1234-567</span></span></a></div>
                    <div class="reveal-inline-block"><a href="mailto:#" class="unit unit-middle unit-horizontal unit-spacing-xs"><span class="unit-left"><span class="icon icon-xxs icon-warning icon-circle mdi mdi-email-outline"></span></span><span class="unit-body"><span class="text-alto">info@demolink.org</span></span></a></div>
                    <div class="reveal-inline-block"><a href="#" class="unit unit-middle unit-horizontal unit-spacing-xs"><span class="unit-left"><span class="icon icon-xxs icon-warning icon-circle mdi mdi-map-marker"></span></span><span class="unit-body"><span class="text-alto">2130 Fulton Street, San Diego, CA 94117-1080 USA</span></span></a></div>
                  </address>
                </div>
                <div class="right-side">
                  <div class="reveal-inline-block text-middle"><a href="#" class="unit unit-middle unit-horizontal unit-spacing-xs"><span class="unit-left text-middle"><span class="icon icon-xxs icon-warning icon-circle mdi mdi-login"></span></span><span class="unit-body"><span class="text-warning">Login/Register</span></span></a></div>
                  <div class="reveal-inline-block text-middle">
                    <ul class="list-inline list-inline-0">
                      <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-facebook"></a></li>
                      <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-twitter"></a></li>
                      <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-google-plus"></a></li>
                      <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-instagram"></a></li>
                      <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-rss"></a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- RD Navbar Panel-->
              <div class="rd-navbar-panel">
                <!-- RD Navbar Toggle-->
                <button data-rd-navbar-toggle=".rd-navbar, .rd-navbar-nav-wrap" class="rd-navbar-toggle"><span></span></button>
                <!-- RD Navbar Top Panel Toggle-->
                <button data-rd-navbar-toggle=".rd-navbar, .rd-navbar-top-panel" class="rd-navbar-top-panel-toggle"><span></span></button>
                <!-- Navbar Brand-->
                <div class="rd-navbar-brand"><a href="index.html"><img width='152' src='images/we_travel_logo.png' alt=''/></a></div>
              </div>
              <div class="rd-navbar-menu-wrap">
                <div class="rd-navbar-nav-wrap">
                  <div class="rd-navbar-mobile-scroll">
                    <!-- Navbar Brand Mobile-->
                    <div class="rd-navbar-mobile-brand"><a href="index.html"><img width='188' height='29' src='images/logo-dark.png' alt=''/></a></div>
                    <div class="form-search-wrap">
                      <!-- RD Search Form-->
                      <form action="search-results.html" method="GET" class="form-search rd-search">
                        <div class="form-group">
                          <label for="rd-navbar-form-search-widget" class="form-label form-search-label form-label-sm rd-input-label">Search</label>
                          <input id="rd-navbar-form-search-widget" type="text" name="s" autocomplete="off" class="form-search-input input-sm form-control form-control-gray-lightest input-sm"/>
                        </div>
                        <button type="submit" class="form-search-submit"><span class="fa fa-search"></span></button>
                      </form>
                    </div>
                    <!-- RD Navbar Nav-->
                    <ul class="rd-navbar-nav">
                      <li><a href="index.html">Home</a></li>
                      <li><a href="about.html">About</a></li>
                      <li class="rd-navbar--has-dropdown rd-navbar-submenu"><a href="country-page.html">Countries</a>
                        <ul class="rd-navbar-dropdown">
                          <li><a href="country-page.html">Germany</a></li>
                          <li><a href="country-page.html">Italy</a></li>
                          <li><a href="country-page.html">Spain</a></li>
                          <li><a href="country-page.html">France</a></li>
                          <li><a href="country-page.html">Thailand</a></li>
                        </ul>
                      </li>
                      <li><a href="guides.html">Guides</a></li>
                      <li class="rd-navbar--has-dropdown rd-navbar-submenu"><a href="blog-classic.html">Tips &amp; Tricks</a>
                        <ul class="rd-navbar-dropdown">
                          <li><a href="blog-classic.html">Classic Blog</a></li>
                          <li><a href="blog-grid.html">Grid Blog</a></li>
                          <li><a href="blog-masonry.html">Masonry Blog</a></li>
                          <li><a href="blog-modern.html">Modern Blog</a></li>
                          <li><a href="single-post.html">Post Page</a></li>
                        </ul>
                      </li>
                      <li><a href="deals.html">Deals</a></li>
                      <li class="active rd-navbar--has-megamenu rd-navbar-submenu"><a href="#">Pages</a>
                        <div class="rd-navbar-megamenu">
                          <div class="row">
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <div>
                                  <h6 class="text-bold text-white">Page 1</h6>
                                </div>
                                <div>
                                  <div style="background: rgba(255,255,255,0.2);" class="hr offset-top-10"></div>
                                </div>
                              </div>
                              <ul class="offset-md-top-5">
                                <li><a href="404.html">404 Page</a></li>
                                <li><a href="503.html">503 Page</a></li>
                                <li><a href="under-construction.html">Under Construction</a></li>
                                <li><a href="search-results.html">Search Results</a></li>
                                <li><a href="site-map.html">Site Map</a></li>
                                <li><a href="privacy.html">Terms of Use</a></li>
                                <li><a href="faq.html">FAQ Page</a></li>
                                <li><a href="testimonials.html">Testimonials</a></li>
                              </ul>
                            </div>
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <div>
                                  <h6 class="text-bold text-white">Page 2</h6>
                                </div>
                                <div>
                                  <div style="background: rgba(255,255,255,0.2);" class="hr offset-top-10"></div>
                                </div>
                              </div>
                              <ul class="offset-md-top-5">
                                <li><a href="careers.html">Careers</a></li>
                                <li><a href="services.html">Services</a></li>
                                <li><a href="single-service.html">Single Service</a></li>
                                <li><a href="our-team.html">Our Team</a></li>
                                <li><a href="team-member.html">Team Member Profile</a></li>
                                <li><a href="country-page.html">Country Page</a></li>
                                <li><a href="guide-page.html">Guide Page</a></li>
                                <li><a href="single-deal.html">Single Deal Page</a></li>
                              </ul>
                            </div>
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <div>
                                  <h6 class="text-bold text-white">Elements</h6>
                                </div>
                                <div>
                                  <div style="background: rgba(255,255,255,0.2);" class="hr offset-top-10"></div>
                                </div>
                              </div>
                              <ul class="offset-md-top-5">
                                <li><a href="typography.html">Typography</a></li>
                                <li><a href="buttons.html">Buttons</a></li>
                                <li><a href="forms.html">Forms</a></li>
                                <li><a href="tables.html">Tables</a></li>
                                <li><a href="tabs-accordions.html">Tabs and Accordions</a></li>
                                <li><a href="progress-bars.html">Progress Bars</a></li>
                                <li><a href="icons.html">Icons</a></li>
                                <li><a href="grid.html">Grid</a></li>
                              </ul>
                            </div>
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <div>
                                  <h6 class="text-bold text-white">Layouts</h6>
                                </div>
                                <div>
                                  <div style="background: rgba(255,255,255,0.2);" class="hr offset-top-10"></div>
                                </div>
                              </div>
                              <ul class="offset-md-top-5">
                                <li><a href="header-corporate.html">Header Corporate</a></li>
                                <li><a href="header-centre-footer-centre-dark.html">Header Centre, Footer Centre Dark</a></li>
                                <li><a href="header-minimal-footer-minimal-dark.html">Header Minimal, Footer Minimal Dark</a></li>
                                <li><a href="Header-transparent-footer-centre-light.html">Header Transparent, Footer Centre Light</a></li>
                                <li><a href="header-hamburger-menu.html">Header Hamburger Menu</a></li>
                                <li><a href="footer-widget-dark.html">Footer Widget Dark</a></li>
                                <li><a href="footer-widget-light.html">Footer Widget Light</a></li>
                                <li><a href="footer-minimal-light.html">Footer Minimal Light</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li class="rd-navbar--has-dropdown rd-navbar-submenu"><a href="gallery-grid.html">Gallery</a>
                        <ul class="rd-navbar-dropdown">
                          <li><a href="gallery-grid.html">Grid Gallery</a></li>
                          <li><a href="grid-without-padding-gallery.html">Grid Without Padding Gallery</a></li>
                          <li><a href="gallery-masonry.html">Masonry Gallery</a></li>
                          <li><a href="cobbles-gallery.html">Cobbles Gallery</a></li>
                        </ul>
                      </li>
                      <li><a href="contacts.html">Contacts</a></li>
                    </ul>
                  </div>
                </div>
                <!-- RD Navbar Search-->
                <div class="rd-navbar-search rd-navbar-search-top-panel"><a data-rd-navbar-toggle=".rd-navbar-inner,.rd-navbar-search" href="#" class="rd-navbar-search-toggle mdi"><span></span></a>
                  <form action="search-results.html" data-search-live="rd-search-results-live" method="GET" class="rd-navbar-search-form search-form-icon-right rd-search">
                    <div class="form-group">
                      <label for="rd-navbar-search-form-input" class="form-label rd-input-label">Type and hit enter...</label>
                      <input id="rd-navbar-search-form-input" type="text" name="s" autocomplete="off" class="rd-navbar-search-form-input form-control form-control-gray-lightest"/>
                    </div>
                    <div id="rd-search-results-live" class="rd-search-results-live"></div>
                  </form>
                </div>
              </div>
            </div>
          </nav>
        </div>
        <!-- Modern Breadcrumbs-->
        <section class="section-height-700 breadcrumb-modern rd-parallax context-dark bg-gray-darkest">
          <div data-speed="0.2" data-type="media" data-url="images/backgrounds/background-06-1920x950.jpg" class="rd-parallax-layer"></div>
          <div data-speed="0" data-type="html" class="rd-parallax-layer">
            <div class="bg-overlay-lg-darker">
              <div class="shell section-top-50 section-bottom-34 section-md-top-90 section-lg-bottom-34 section-lg-top-128">
                <div class="veil reveal-md-block">
                  <h5 class="reveal-inline-block font-default both-lines text-italic">Account Management</h5>
                </div>
                <div class="veil reveal-md-block offset-top-8">
                  <h1 class="text-bold">Welcome!</h1>
                </div>
                <ul class="list-inline list-inline-icon p offset-top-35 offset-md-top-63 offset-lg-top-108">
                  <li class="text-warning"><a href="index.html">Home</a></li>
                  <li class="text-warning"><a href="#">Elements</a></li>
                  <li>Account</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </header>
      <!-- Page Contents-->
      <main class="page-content">
        <section class="section-90 section-md-122 text-sm-left">
          <div class="shell-wide">
            <!-- Login Form-->
            <div class="range range-xs-center range-lg-left">
              <div class="cell-sm-8 cell-md-7 cell-lg-6 cell-xl-3 cell-lg-preffix-2 cell-xl-preffix-3">
                <div>
                  <h4 class="text-bold">Your Personalized Offers - coming Soon - </h4>
                </div>
                <div class="offset-top-10">
                  <div class="hr bg-gray"></div>
                </div>
                <div class="offset-top-20">
                  <!-- RD Mailform-->
                  <form name="login-form" method="post" action="account.php">
                    <div id="crmid-lookup">
            
                      <input style="color:white;" id="login" type="text" name="text" data-constraints="@Required" value="<?php echo $username; ?>" class="form-control-invisible">
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <!-- Newsletter-->
            <div class="range range-xs-center range-lg-left offset-top-90 offset-md-top-122"> </div>
            <!-- Registration Form-->
            <!-- Contact Us-->
            <div class="range range-xs-center range-lg-left offset-top-90 offset-md-top-122"> </div>
          </div>
        </section>
      </main>
      <!-- Page Footer-->
      <!-- Footer Default-->
      <footer class="section-relative section-90 page-footer bg-ebony-clay context-dark">
        <div class="shell-wide">
          <div class="range range-xs-center range-xl-justify text-lg-left">
            <div class="cell-xs-8 cell-sm-5 cell-md-4 cell-lg-3 cell-xl-2 cell-sm-push-2">
              <h4>Contact Us</h4>
              <div class="text-subline"></div>
              <!-- Contact Info-->
              <address class="contact-info text-left offset-top-20">
                <div class="reveal-inline-block"><a href="callto:#" class="unit unit-middle unit-horizontal unit-spacing-xs"><span class="unit-left"><span class="icon icon-xxs icon-warning icon-circle mdi mdi-phone"></span></span><span class="unit-body"><span class="text-alto">1-800-1234-567</span></span></a></div>
                <div class="reveal-inline-block"><a href="mailto:#" class="unit unit-middle unit-horizontal unit-spacing-xs offset-top-18"><span class="unit-left"><span class="icon icon-xxs icon-warning icon-circle mdi mdi-email-outline"></span></span><span class="unit-body"><span class="text-alto">info@demolink.org</span></span></a></div>
                <div class="reveal-inline-block"><a href="#" class="unit unit-horizontal unit-spacing-xs offset-top-18"><span class="unit-left"><span class="icon icon-xxs icon-warning icon-circle mdi mdi-map-marker"></span></span><span class="unit-body"><span class="text-alto">2130 Fulton Street, San Diego, <br class="veil reveal-lg-inline-block"> CA 94117-1080 USA</span></span></a></div>
              </address>
            </div>
            <div class="cell-xs-10 cell-sm-8 cell-md-5 cell-lg-3 cell-xl-3 offset-top-66 offset-lg-top-0 cell-sm-push-3">
              <h4>Newsletter</h4>
              <div class="text-subline"></div>
              <p class="text-alto">Enter your email address to get the latest traveling news, special offers and other discount information delivered right to your inbox.</p>
              <div class="offset-top-30">
                      <form data-form-output="form-subscribe-footer" data-form-type="subscribe" method="post" action="bat/rd-mailform.php" class="rd-mailform rd-mailform-subscribe">
                        <div class="form-group">
                          <div class="input-group">
                            <input placeholder="Enter your e-mail" type="email" name="email" data-constraints="@Required @Email" class="form-control"><span class="input-group-btn">
                              <button type="submit" class="btn btn-sm btn-primary">Subscribe</button></span>
                          </div>
                        </div>
                        <div id="form-subscribe-footer" class="form-output"></div>
                      </form>
              </div>
            </div>
            <div class="cell-xs-8 cell-sm-5 cell-md-4 cell-lg-3 cell-xl-2 offset-top-66 offset-lg-top-0 cell-sm-push-4">
              <h4>@wetravel</h4>
              <div class="text-subline"></div>
              <div class="offset-top-20">
                      <div data-photo-swipe="gallery" data-flickr-tags="tm60026" class="flickr widget-flickrfeed group-sm"><a data-photo-swipe-item="" href="" data-image_c="href" data-size="800x800" data-type="flickr-item" class="flickr-item thumbnail-classic"><img width="82" height="82" data-title="alt" src="images/_blank.png" alt="" data-image_q="src"></a><a data-photo-swipe-item="" href="" data-image_c="href" data-size="800x800" data-type="flickr-item" class="flickr-item thumbnail-classic"><img width="82" height="82" data-title="alt" src="images/_blank.png" alt="" data-image_q="src"></a><a data-photo-swipe-item="" href="" data-image_c="href" data-size="800x800" data-type="flickr-item" class="flickr-item thumbnail-classic"><img width="82" height="82" data-title="alt" src="images/_blank.png" alt="" data-image_q="src"></a><a data-photo-swipe-item="" href="" data-image_c="href" data-size="800x800" data-type="flickr-item" class="flickr-item thumbnail-classic"><img width="82" height="82" data-title="alt" src="images/_blank.png" alt="" data-image_q="src"></a><a data-photo-swipe-item="" href="" data-image_c="href" data-size="800x800" data-type="flickr-item" class="flickr-item thumbnail-classic"><img width="82" height="82" data-title="alt" src="images/_blank.png" alt="" data-image_q="src"></a><a data-photo-swipe-item="" href="" data-image_c="href" data-size="800x800" data-type="flickr-item" class="flickr-item thumbnail-classic"><img width="82" height="82" data-title="alt" src="images/_blank.png" alt="" data-image_q="src"></a>
                      </div>
              </div>
            </div>
            <div class="cell-xs-10 cell-sm-6 cell-md-4 cell-lg-3 cell-xl-2 offset-top-66 offset-sm-top-0">
              <!-- Footer brand-->
              <div class="footer-brand"><a href="index.html"><img width='152' src='images/we_travel_logo.png' alt=''/></a></div>
              <ul class="list-inline list-inline-2 reveal-inline-block offset-top-30">
                <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-facebook"></a></li>
                <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-twitter"></a></li>
                <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-google-plus"></a></li>
                <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-instagram"></a></li>
                <li><a href="#" class="icon icon-xxs icon-boulder-filled icon-circle fa fa-rss"></a></li>
              </ul>
              <p class="no-md-wrap text-dark offset-xl-top-108">&copy; <span id="copyright-year"></span>. All rights reserved. <br class="veil-xs"> <a href="privacy.html">Privacy Policy</a>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!-- Global Mailform Output-->
    <div id="form-output-global" class="snackbars"></div>
    <!-- PhotoSwipe Gallery-->
    <div tabindex="-1" role="dialog" aria-hidden="true" class="pswp">
      <div class="pswp__bg"></div>
      <div class="pswp__scroll-wrap">
        <div class="pswp__container">
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
        </div>
        <div class="pswp__ui pswp__ui--hidden">
          <div class="pswp__top-bar">
            <div class="pswp__counter"></div>
            <button title="Close (Esc)" class="pswp__button pswp__button--close"></button>
            <button title="Share" class="pswp__button pswp__button--share"></button>
            <button title="Toggle fullscreen" class="pswp__button pswp__button--fs"></button>
            <button title="Zoom in/out" class="pswp__button pswp__button--zoom"></button>
            <div class="pswp__preloader">
              <div class="pswp__preloader__icn">
                <div class="pswp__preloader__cut">
                  <div class="pswp__preloader__donut"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
            <div class="pswp__share-tooltip"></div>
          </div>
          <button title="Previous (arrow left)" class="pswp__button pswp__button--arrow--left"></button>
          <button title="Next (arrow right)" class="pswp__button pswp__button--arrow--right"></button>
          <div class="pswp__caption">
            <div class="pswp__caption__center"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Java script-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>